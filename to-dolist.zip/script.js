let taskList = [];

function addTask() {
  const taskInput = document.getElementById('task-input');
  const taskText = taskInput.value.trim();

  if (taskText) {
    taskList.push({ text: taskText, id: Date.now() });
    taskInput.value = '';
    renderTasks();
  }
}

function editTask(id) {
  const newTaskText = prompt('Edit your task:', taskList.find(task => task.id === id).text);

  if (newTaskText !== null && newTaskText.trim() !== '') {
    taskList = taskList.map(task => 
      task.id === id ? { ...task, text: newTaskText } : task
    );
    renderTasks();
  }
}

function deleteTask(id) {
  taskList = taskList.filter(task => task.id !== id);
  renderTasks();
}

function renderTasks() {
  const taskListElement = document.getElementById('task-list');
  taskListElement.innerHTML = '';

  taskList.forEach(task => {
    const li = document.createElement('li');
    li.innerHTML = `
      <span>${task.text}</span>
      <div>
        <button onclick="editTask(${task.id})">Edit</button>
        <button class="delete" onclick="deleteTask(${task.id})">Delete</button>
      </div>
    `;
    taskListElement.appendChild(li);
  });
}